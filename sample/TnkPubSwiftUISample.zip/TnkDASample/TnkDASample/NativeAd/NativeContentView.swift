//
//  NativeContentView.swift
//  TnkDASample
//
//  Created by KyoungBeen.Seo on 2023/10/24.
//

import Foundation
import SwiftUI
import TnkPubSdk

struct NativeContentView : View
{
    @ObservedObject
    private var viewModel = NativelistContentViewModel()
    
    var body : some View
    {
        TnkNativeADSwiftUIView(adItem:viewModel.adItem) { adItem in
            AnyView(
                VStack{
                    Image(uiImage: adItem?.getIconImage() ?? UIImage())
                        .resizable()
                        .frame(width: 150, height: 150)
                        .aspectRatio(contentMode: .fit)
                        .padding(.top,25)
                    Text(adItem?.getTitle() ?? "")
                    Image(uiImage: adItem?.getMainImage() ?? UIImage())
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                    Text(adItem?.getDescription() ?? "")
                    Spacer()
                }.onDisappear{
                    viewModel.adItem?.releaseAd()
                }
            )
        }
    }
}


