//
//  NativeListContentView.swift
//  TnkDASample
//
//  Created by KyoungBeen.Seo on 2023/10/26.
//

import Foundation
import SwiftUI
import TnkPubSdk

struct NativeListContentView : View
{
    @ObservedObject
    private var viewModel = NativelistContentViewModel()
    
    var body : some View
    {
        List(0..<4,id:\.self){ id in
            NativeRow(id: id,viewModel: viewModel).listRowSeparator(.hidden)
        }
        .listStyle(.plain)
        .onDisappear{
            viewModel.adItem?.releaseAd()
        }
    }
}


struct NativeRow : View
{
    let id: Int
    @ObservedObject
    private var viewModel: NativelistContentViewModel

    init(id: Int, viewModel: NativelistContentViewModel) {
        self.id = id
        self.viewModel = viewModel
    }
    
    var body : some View{
        if(id == 3)
        {
            TnkNativeADSwiftUIView(adItem: viewModel.adItem) { adItem in
                AnyView(
                    HStack(alignment:.top){
                        Image(uiImage: adItem?.getIconImage() ?? UIImage())
                            .resizable()
                            .frame(width: 100, height: 100)
                            .aspectRatio(contentMode: .fit)
                            .padding(.top,10)
                            .padding(.bottom,10)
                            .padding(.leading,15)
                        VStack(alignment:.leading){
                            Text(adItem?.getTitle() ?? "")
                                .padding(.top,5)
                            Text(adItem?.getDescription() ?? "")
                                .lineLimit(3)
                                .padding(.top,15)
                        }.padding(.trailing,15)
                        Spacer()
                        
                    }.frame(minWidth: 0,maxWidth: .infinity,minHeight: 120,maxHeight: 400)
                )
            }
        }else{
            VStack{
                Text("임의 컨텐츠 영역-\(id)")
                    .frame(height:120)
                    .font(Font.headline.bold())
            }.frame(
                minWidth: 0,
                maxWidth: .infinity,
                minHeight: 0,
                maxHeight: .infinity,
                alignment: .center
            ).border(.blue)
            .padding(EdgeInsets(top: 5, leading: 15, bottom: 5, trailing: 15))
        }
    }
}
