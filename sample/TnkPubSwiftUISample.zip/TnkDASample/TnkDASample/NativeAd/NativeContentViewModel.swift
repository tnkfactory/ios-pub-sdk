//
//  NativeContentViewModel.swift
//  TnkDASample
//
//  Created by KyoungBeen.Seo on 2023/10/26.
//

import Foundation
import SwiftUI
import TnkPubSdk

class NativelistContentViewModel : ObservableObject,TnkAdListener
{
    @Published var adItem : TnkNativeAdItem?
    private var _adTtem : TnkNativeAdItem?
    init(){
        _adTtem = TnkNativeAdItem(placementId: "TEST_NATIVE", adListener: self)
        _adTtem?.load()
    }
    
    func onLoad(_ adItem: TnkAdItem) {
        if let item = adItem as? TnkNativeAdItem
        {
            self.adItem = item
        }
    }
}
