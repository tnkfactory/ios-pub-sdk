//
//  ViewDidLoadModifier.swift
//  TnkDASample
//
//  Created by KyoungBeen.Seo on 2023/10/23.
//

import Foundation
import SwiftUI

struct ViewDidloadModifier : ViewModifier{
    @State private var viewDidLoad = false
    let action  : (() -> Void)?
    
    func body(content : Content) -> some View{
        content
            .onAppear{
                if !viewDidLoad {
                    viewDidLoad = false
                    action?()
                }
            }
    }
    
}
