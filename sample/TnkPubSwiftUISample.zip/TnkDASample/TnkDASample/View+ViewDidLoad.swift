//
//  View+ViewDidLoad.swift
//  TnkDASample
//
//  Created by KyoungBeen.Seo on 2023/10/23.
//

import Foundation
import SwiftUI

extension View
{
    func onViewDidLoad(perform action:(() -> Void)? = nil) -> some View
    {
        self.modifier(ViewDidloadModifier(action: action))
    }
}

