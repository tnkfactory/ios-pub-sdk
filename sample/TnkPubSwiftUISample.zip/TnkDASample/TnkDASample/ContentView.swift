//
//  ContentView.swift
//  TnkDASample
//
//  Created by KyoungBeen.Seo on 2023/10/23.
//

import SwiftUI
import AppTrackingTransparency

struct ContentView: View {
    
    @State var interstitialAdOpened = false
    @State var adBannerOpened = false
    @State var adNativeOpened = false
    @State var adNativeListOpened = false
    @State var videoAdOpened = false
    
    var body: some View {
        List{
            Section(header: Text("광고 종류")) {
                Text("전면 광고 (Interstitial Ad)").onTapGesture {
                    interstitialAdOpened = true
                }
                Text("배너 광고 (Banner Ad)")
                    .onTapGesture {
                        adBannerOpened = true
                    }
                    
                Text("네이티브 광고 - 전면(Native Ad)")
                    .onTapGesture {
                        adNativeOpened = true
                    }
                Text("네이티브 광고 -리스트(Native Ad)")
                    .onTapGesture {
                        adNativeListOpened = true
                    }
                Text("동영상 광고 (Video Ad)")
                    .onTapGesture {
                        videoAdOpened = true
                    }
            }
        }
        .navigationTitle("TNK SwiftUI Sample")
        .listStyle(GroupedListStyle())
        .onViewDidLoad{
            print("view did loaded")
        }.onReceive(NotificationCenter.default.publisher(for: UIApplication.didBecomeActiveNotification)) { _ in
            //광고 추적 동의
            ATTrackingManager.requestTrackingAuthorization { staus in
                print("stauts = \(staus)")
            }
        }.fullScreenCover(isPresented: $interstitialAdOpened, content: {
            InterstitialAdView(placementId: "TEST_INTERSTITIAL_V")
        }).sheet(isPresented: $adBannerOpened) {
            BannerContentView()
        }.sheet(isPresented: $adNativeOpened) {
            NativeContentView()
        }.sheet(isPresented: $adNativeListOpened) {
            NativeListContentView()
        }.fullScreenCover(isPresented: $videoAdOpened, content: {
            InterstitialAdView(placementId: "TEST_REWARD_V")
        })
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
