//
//  BannerContentView.swift
//  TnkDASample
//
//  Created by KyoungBeen.Seo on 2023/10/23.
//

import Foundation
import SwiftUI

struct BannerContentView : View
{
    var body : some View
    {
        ScrollView{
            LazyVStack{
                ForEach(0...3,id:\.self,content: BannerRow.init)
            }
        }
        
    }
}


struct BannerRow : View
{
    let id : Int
    var bannerView : BannerAdView?
    
    var body : some View{
        if(id == 3)
        {
            VStack{
                GeometryReader{proxy in
                    BannerAdView(frame: proxy.frame(in: .local))
                }
            }
            .frame(height:UIScreen.main.bounds.width * 50.0 / 320.0)
            .onDisappear{
                print("disapear!!")
            }
        }else{
            VStack{
                Text("임의 컨텐츠 영역-\(id)")
                    .frame(height:150)
                    .font(Font.headline.bold())
            }.frame(
                minWidth: 0,
                maxWidth: .infinity,
                minHeight: 0,
                maxHeight: .infinity,
                alignment: .center
            ).border(.blue)
            .padding(EdgeInsets(top: 5, leading: 15, bottom: 5, trailing: 15))
        }
    }
    
    init(id: Int)
    {
        self.id = id
    }
    
}
