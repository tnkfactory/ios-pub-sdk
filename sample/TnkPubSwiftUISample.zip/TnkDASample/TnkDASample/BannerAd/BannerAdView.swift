//
//  BannerAdView.swift
//  TnkDASample
//
//  Created by KyoungBeen.Seo on 2023/10/23.
//

import Foundation
import SwiftUI
import UIKit
import TnkPubSdk

struct BannerAdView : UIViewRepresentable
{
    typealias UIViewType = TnkBannerAdView
    let frame : CGRect
    
    func makeUIView(context: Context) -> TnkBannerAdView {
        let bannerView = TnkBannerAdView(placementId: "TEST_BANNER_100", adListener: context.coordinator)
        bannerView.frame = frame
        bannerView.load()
        return bannerView
    }
    
    func updateUIView(_ uiView: TnkBannerAdView, context: Context) {
       print("update view!")
    }
    
    func makeCoordinator() -> BannerCodinator {
        BannerCodinator()
    }
    
    class BannerCodinator: NSObject,TnkAdListener
    {
        func onLoad(_ adItem:TnkAdItem) {
            adItem.show()
        }
        
        func onClose(_ adItem: TnkAdItem, type: AdClose) {
            print("close!!")
        }
    }
    
}
