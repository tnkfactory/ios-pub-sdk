//
//  TnkDASampleApp.swift
//  TnkDASample
//
//  Created by KyoungBeen.Seo on 2023/10/23.
//

import SwiftUI

@main
struct TnkDASampleApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView{
                ContentView()
            }
            
        }
    }
}
