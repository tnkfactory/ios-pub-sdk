//
//  InterstitialAdView.swift
//  TnkDASample
//
//  Created by KyoungBeen.Seo on 2023/10/23.
//

import Foundation
import SwiftUI
import UIKit
import TnkPubSdk

struct InterstitialAdView : UIViewControllerRepresentable
{
    typealias UIViewControllerType = InterstitialAdViewController
    let placementId : String
    
    func makeUIViewController(context: Context) -> InterstitialAdViewController {
        let vc = InterstitialAdViewController(placementId: placementId)
        return vc
    }
    
    func updateUIViewController(_ uiViewController: InterstitialAdViewController, context: Context) {
        
    }
}

class InterstitialAdViewController : UIViewController,TnkAdListener
{
    var adItem : TnkInterstitialAdItem?
    let placementId : String
    
    init(placementId: String) {
        self.placementId = placementId
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        adItem = TnkInterstitialAdItem(viewController: self,
                                                      placementId: placementId)
        adItem?.setListener(self)
        adItem?.load()
    }
    
    
    func onLoad(_ adItem: TnkAdItem) {
        adItem.show()
    }
    
    func onVideoCompletion(_ adItem: TnkAdItem, verifyCode: Int) {
        self.dismiss(animated: true)
    }
    
    func onClose(_ adItem: TnkAdItem, type: AdClose) {
        self.dismiss(animated: true)
    }
    
}
